def funcion_paquete():
    print("Hola soy un paquete pelado")