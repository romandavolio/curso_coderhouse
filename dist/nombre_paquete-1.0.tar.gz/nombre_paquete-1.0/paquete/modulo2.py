def funcion_paquete2():
    print("Hola soy un paquete pelado2")