from setuptools import setup

setup( 
name='nombre_paquete', 
version = '1.0', 
description = 'mi primer paquete redistribuible', 
author = 'Nombre',
packages = ['paquete'])
